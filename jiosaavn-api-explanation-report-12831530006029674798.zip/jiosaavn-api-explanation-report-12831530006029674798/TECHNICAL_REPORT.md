# 🎵 JioSaavn API: Technical Architecture & Implementation Report

This report provides a detailed breakdown of the `jiosaavn-api` repository, explaining its architecture, data fetching mechanisms, and the intricate process of song data handling and decryption.

---

## 1. Project Overview & Tech Stack
The project is an unofficial wrapper for the JioSaavn API, designed to provide programmatic access to music metadata and high-quality download links.

- **Runtime**: [Bun](https://bun.sh/) (primary) or Node.js.
- **Framework**: [Hono](https://hono.dev/) - A small, fast, web framework for the Edges.
- **Validation & Docs**: [Zod](https://zod.dev/) and [@hono/zod-openapi](https://github.com/honojs/middleware/tree/main/packages/zod-openapi) for schema validation and automated Swagger documentation.
- **Language**: TypeScript.

## 2. Architecture: Modular Clean Architecture
The codebase follows a highly structured modular design, separating concerns into distinct layers:

- **Controllers** (`src/modules/*/controllers`): Define the HTTP endpoints, request/response schemas (using Zod), and route the logic to services.
- **Services** (`src/modules/*/services`): Act as an orchestration layer, initializing and calling specific use cases.
- **Use Cases** (`src/modules/*/use-cases`): Contain the core business logic for a single operation (e.g., `GetSongByIdUseCase`).
- **Models** (`src/modules/*/models`): Define the data structure for both the raw JioSaavn API response and the cleaned-up internal API response.
- **Helpers** (`src/modules/*/helpers`): Utility functions for data transformation, link decryption, and fetching.

---

## 3. Data Fetching Mechanism
All data is fetched directly from JioSaavn's internal endpoints.

### The `useFetch` Helper (`src/common/helpers/fetch.helper.ts`)
This is the heart of the data retrieval logic. It constructs requests to JioSaavn's PHP-based API:
- **Base URL**: `https://www.jiosaavn.com/api.php`
- **Mandatory Query Params**:
    - `__call`: The internal JioSaavn function name (e.g., `song.getDetails`). Defined in `src/common/constants/endpoint.constant.ts`.
    - `_format`: Set to `json`.
    - `_marker`: Set to `0`.
    - `api_version`: Set to `4`.
    - `ctx`: Context, usually `web6dot0` or `android`.
- **Headers**:
    - Randomizes the `User-Agent` from a predefined list (`src/common/constants/user-agents.constant.ts`) to avoid rate limiting and mimic real browser/app traffic.

---

## 4. Deep Dive: Song Data Fetching
Fetching a song involves several steps of transformation.

### Fetching by ID vs. Link
1. **By ID**: Uses the `song.getDetails` call with the `pids` parameter (comma-separated IDs).
2. **By Link**: Uses the `webapi.get` call. It takes a "token" (the last part of a JioSaavn URL) and a `type=song`.

### Data Transformation (`src/modules/songs/helpers/song.helper.ts`)
The raw API response from JioSaavn is often cluttered and uses inconsistent naming. The `createSongPayload` helper maps this to a clean format:
- `title` becomes `name`.
- `perma_url` becomes `url`.
- Image links are expanded into multiple qualities (50x50, 150x150, 500x500).
- Play counts and durations are cast to numbers.

---

## 5. Download Link Decryption (The "Secret Sauce")
JioSaavn does not provide direct MP3/AAC links in the raw response. Instead, it provides an `encrypted_media_url`.

### The Decryption Process (`src/common/helpers/link.helper.ts`)
1. **Algorithm**: DES-ECB (Electronic Codebook mode).
2. **Key**: `38346591` (Static).
3. **IV**: `00000000` (Static).
4. **Logic**:
   - The `encrypted_media_url` (Base64 encoded) is first decoded.
   - It is decrypted using the DES key.
   - The result is a URL that typically ends in a `_96.mp4` or `_96.aac` suffix.

### Generating Bitrates
Once the base decrypted link is obtained, the API generates five quality levels by replacing the bitrate suffix in the URL:
- **12kbps**: `_12`
- **48kbps**: `_48`
- **96kbps**: `_96`
- **160kbps**: `_160`
- **320kbps**: `_320`

---

## 6. Advanced Features: Suggestions & Radio
### Song Suggestions
- Suggestions are not a direct "related songs" call.
- The API first calls `webradio.createEntityStation` to create a virtual "station" based on a song ID.
- It then calls `webradio.getSong` using the `stationid` to get recommended tracks.
- This specifically requires the `android` context (`ApiContextEnum.ANDROID`) to work correctly.

---

## 7. Development & Deployment
- **Tests**: Powered by Vitest, covering controllers and use cases. Run with `bun run test`.
- **Documentation**: Accessing `/docs` on a running instance serves a Scalar-powered Swagger UI, generated dynamically from Zod schemas.
- **Deployment**: Configured for Cloudflare Workers (`wrangler.toml`) and Vercel (`vercel.json`).
